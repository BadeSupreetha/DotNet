﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(101, "Robert", 30000, Convert.ToDateTime("10/16/1996"));

            Console.WriteLine("Employee ID : " + emp.EmployeeID);
            Console.WriteLine("Employee Name : " + emp.EmployeeName);
            Console.WriteLine("Employee Salary : " + emp.Salary);
            Console.WriteLine("Employee Date of birth : " + emp.Dob);
            

            Console.ReadKey();
        }
    }
}
